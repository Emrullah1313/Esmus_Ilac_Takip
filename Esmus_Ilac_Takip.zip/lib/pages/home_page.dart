import 'package:flutter/material.dart';
import 'add_medicine_page.dart';
import '../services/database_helper.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> _medicines = [];

  @override
  void initState() {
    super.initState();
    _refreshMedicines();
  }

  void _refreshMedicines() async {
    final data = await DatabaseHelper.getMedicines();
    setState(() {
      _medicines = data;
    });
  }

  void _scanQrCode() async {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: Text("QR Kod Tara")),
        body: MobileScanner(
          onDetect: (capture) {
            final String code = capture.barcodes.first.rawValue ?? '';
            Navigator.of(context).pop();
            _searchByQr(code);
          },
        ),
      ),
    ));
  }

  void _searchByQr(String code) async {
    final data = await DatabaseHelper.getMedicineByQr(code);
    if (data != null) {
      _showMedicineDialog(data);
    } else {
      _showNotFoundDialog(code);
    }
  }

  void _showMedicineDialog(Map<String, dynamic> medicine) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(medicine['name']),
        content: Text("Açıklama: ${medicine['description']}
Son Kullanma: ${medicine['expiry']}"),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("Tamam"))],
      ),
    );
  }

  void _showNotFoundDialog(String code) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("İlaç bulunamadı"),
        content: Text("QR kodu: $code
Bu kodla eşleşen ilaç bulunamadı."),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text("Kapat"))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Esmus İlaç Takip'),
        actions: [IconButton(onPressed: _scanQrCode, icon: Icon(Icons.qr_code_scanner))],
      ),
      body: _medicines.isEmpty
          ? Center(child: Text("Henüz ilaç eklenmedi"))
          : ListView.builder(
              itemCount: _medicines.length,
              itemBuilder: (ctx, i) => ListTile(
                title: Text(_medicines[i]['name']),
                subtitle: Text("Son Kullanma: ${_medicines[i]['expiry']}"),
              ),
            ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => AddMedicinePage()));
          _refreshMedicines();
        },
      ),
    );
  }
}
