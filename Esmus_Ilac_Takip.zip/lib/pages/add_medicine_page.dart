import 'package:flutter/material.dart';
import '../services/database_helper.dart';

class AddMedicinePage extends StatefulWidget {
  @override
  _AddMedicinePageState createState() => _AddMedicinePageState();
}

class _AddMedicinePageState extends State<AddMedicinePage> {
  final _formKey = GlobalKey<FormState>();
  String name = '';
  String description = '';
  String expiry = '';
  String qr = '';

  void _saveMedicine() async {
    if (_formKey.currentState!.validate()) {
      await DatabaseHelper.insertMedicine({
        'name': name,
        'description': description,
        'expiry': expiry,
        'qr': qr,
      });
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("İlaç Ekle")),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(decoration: InputDecoration(labelText: 'İlaç Adı'), onChanged: (v) => name = v),
              TextFormField(decoration: InputDecoration(labelText: 'Açıklama'), onChanged: (v) => description = v),
              TextFormField(decoration: InputDecoration(labelText: 'Son Kullanma Tarihi'), onChanged: (v) => expiry = v),
              TextFormField(decoration: InputDecoration(labelText: 'QR/Barkod (isteğe bağlı)'), onChanged: (v) => qr = v),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _saveMedicine, child: Text("Kaydet")),
            ],
          ),
        ),
      ),
    );
  }
}
