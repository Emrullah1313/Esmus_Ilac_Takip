import 'package:flutter/material.dart';
import 'pages/home_page.dart';
void main() {
  runApp(EsmusApp());
}
class EsmusApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Esmus İlaç Takip',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}
